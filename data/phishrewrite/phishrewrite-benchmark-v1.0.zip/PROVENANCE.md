# Provenance & datasheet — PhishRewrite v1.0

## Composition

- **5390 phishing** emails (label 1), source: **Nazario phishing corpus**.
- **22811 ham** emails (label 0), sources: **SpamAssassin** (`easy_ham`,
  `easy_ham_2`, `hard_ham` — ham subsets ONLY; spam subsets excluded by design)
  and **Enron** (a seeded sample for legitimate-email diversity).
- Natural class ratio ~1:4.2 phishing:ham; left unbalanced (handled in-model).
- Train/test split: stratified, seed=42, test_size=0.2.

## Rewrites

- LLM rewrites of held-out **test** phishing only (ham is never attacked).
- Severities 0.25 / 0.5 / 0.75 / 1.0 (cumulative aggressiveness); the system +
  per-severity prompts ship in `prompts/`.
- Label-validity contract: preserve the malicious ask and reproduce every URL verbatim.
- Models: Claude Haiku 4.5 (headline) and Gemini 2.5 Flash (cross-model check).
- `4000` rewrite rows total.

## Transform applied for release

- URLs defanged scheme-only and **losslessly**: `http://`->`hxxp://`,
  `https://`->`hxxps://`, `www.`->`www[.]`. Reverse with `refang.py`.
- No other modification to the text. Features in the source repo were computed
  pre-defang on verbatim URLs; re-fang before recomputing URL-based features.

## Source terms

- Nazario corpus: research use; cite the corpus. URLs defanged on release.
- SpamAssassin public corpus: distributed for anti-spam research.
- Enron corpus (Klimt & Yang, 2004): public.

See `LICENSE` for the combined data-license terms and restrictions.

## Ethics

Defensive-use-only. This benchmark exists to quantify and help close a weakness
in content-based detectors. Do not use it to build or improve phishing attacks.
