"""Restore verbatim URLs in the PhishRewrite release (inverse of the
scheme-only defang applied for distribution).

    python refang.py emails.csv emails_refanged.csv

Defang here is lossless, so re-fanging then recomputing URL features reproduces
the original feature values. Re-fanged links are live — do not visit them.
"""
import re
import sys
import pandas as pd

DEFANGED_URL_RE = re.compile(r"hxxps?://\S+|www\[\.\]\S+", re.IGNORECASE)


def _refang_token(u: str) -> str:
    u = re.sub(r"^hxxps://", "https://", u, flags=re.IGNORECASE)
    u = re.sub(r"^hxxp://", "http://", u, flags=re.IGNORECASE)
    if u[:6].lower() == "www[.]":
        u = "www." + u[6:]
    return u


def refang(text: str) -> str:
    text = DEFANGED_URL_RE.sub(lambda m: _refang_token(m.group(0)), str(text or ""))
    return text.replace("hxxps://", "https://").replace("hxxp://", "http://")


if __name__ == "__main__":
    src, dst = sys.argv[1], sys.argv[2]
    df = pd.read_csv(src)
    for col in df.columns:
        if df[col].dtype == object:
            df[col] = df[col].map(refang)
    df.to_csv(dst, index=False)
    print(f"refanged {src} -> {dst}")
