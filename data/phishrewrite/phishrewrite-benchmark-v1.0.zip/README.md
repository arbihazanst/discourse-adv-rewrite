---
license: other
license_name: phishrewrite-data-license
license_link: LICENSE
language:
- en
task_categories:
- text-classification
tags:
- phishing
- email
- adversarial-robustness
- security
pretty_name: PhishRewrite
configs:
- config_name: emails
  data_files: data/emails.csv
- config_name: rewrites
  data_files: data/rewrites.csv
---

# PhishRewrite benchmark v1.0

A benchmark measuring how content-based phishing-email detectors degrade when
phishing text is rewritten by a large language model to read benign **while
preserving the malicious ask and every URL**. Defensive research only — read
`ETHICS` before use.

> **All URLs in this release are defanged** (`http://`->`hxxp://`,
> `https://`->`hxxps://`, `www.`->`www[.]`). The transform is scheme-only and
> **losslessly reversible**: run `refang.py` (shipped here) to restore verbatim
> URLs before recomputing URL features. Do not visit any link.

## Configs

| config | rows | description |
|---|---|---|
| `emails` | 28201 | labeled phishing/ham emails with a fixed train/test split |
| `rewrites` | 4000 | LLM rewrites of held-out **test** phishing at 4 severities |

```python
from datasets import load_dataset
emails   = load_dataset("phishrewrite", "emails")     # or data_files=...
rewrites = load_dataset("phishrewrite", "rewrites")
```

## `emails` schema

| column | type | meaning |
|---|---|---|
| `id` | string | stable unique id within the table |
| `label` | int | 1 = phishing, 0 = ham |
| `source` | string | `nazario` (phishing) / `spamassassin`, `enron` (ham) |
| `split` | string | `train` or `test` (stratified, seed=42) |
| `original_id` | string | source-local id (traces back to the raw message) |
| `had_html` | bool | did the raw body contain HTML before stripping? |
| `subject` | string | parsed subject (defanged) |
| `body` | string | HTML-stripped plain-text body (defanged) |
| `text` | string | `subject` + `body` — the model/feature input (defanged) |

## `rewrites` schema

| column | type | meaning |
|---|---|---|
| `original_id` | string | the test phishing email this rewrites (join to `emails`) |
| `source` | string | always `nazario` |
| `severity` | float | rewrite aggressiveness: 0.25 / 0.5 / 0.75 / 1.0 |
| `provider`, `model` | string | rewriting model (claude-haiku-4-5 or gemini-2.5-flash) |
| `temperature` | float | sampling temperature |
| `refused` | bool | model returned meta-text instead of an email |
| `n_orig_urls` | int | URLs in the original email |
| `retained_urls_strict` | bool/null | strict: ALL original URLs preserved (null = no URL) |
| `retained_urls_primary` | bool/null | relaxed: ask-bearing URL(s) kept (null = no anchor) |
| `n_primary_urls` | int | number of ask-bearing URLs identified in the original |
| `rewrite_subject`, `rewrite_body`, `rewrite_text` | string | the rewrite (defanged) |

The two retention columns are the strict and primary label-validity definitions
documented in `LIMITATIONS`. The headline degradation set uses the strict
definition.

## Provenance

See `PROVENANCE.md`. Sources: the Nazario phishing corpus (phishing), the
SpamAssassin public corpus (ham subsets only), and the Enron email corpus
(sampled ham). SpamAssassin spam is excluded by design. Seed = 42.

## Citation

```bibtex
@misc{phishrewrite10,
  title        = {PhishRewrite: Measuring Phishing-Detector Degradation under LLM Rewriting},
  author       = {Katyal, Gaurang},
  year         = {2026},
  howpublished = {Zenodo},
  note         = {Version 1.0. Defensive-research benchmark. DOI: <add on upload>}
}
```

Please also cite the underlying corpora (Nazario; SpamAssassin; Klimt & Yang,
the Enron corpus) — see `PROVENANCE.md` for details.

## License

Code: MIT. Data / derived benchmark: see `LICENSE` (`DATA_LICENSE` in the source
repo). Defensive use only.
